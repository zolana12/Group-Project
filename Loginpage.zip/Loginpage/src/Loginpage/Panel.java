package Loginpage;

import Loginpage.PiePanel;

public class Panel extends PiePanel {

    public static void main(String[] args) {
//This code is copied from the main method of the JFrame PiePanel, which allows the frame to be executed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PiePanel().setVisible(true);
            }
        });

    }

}
