/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Loginpage;

/**
 *
 * @author emiel
 */
import panel.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.jdbc.JDBCCategoryDataset;

public class SDP2 {

    /**
     * @param args the command line arguments
     */
    private static Connection con;
    public Statement st;
    private static JDBCCategoryDataset dataset;

    
    public static void main(String[] args) {
        // TODO code application logic here
        SDP2 obj = new SDP2();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyPanel().setVisible(true);
            }
        });

    }

}
