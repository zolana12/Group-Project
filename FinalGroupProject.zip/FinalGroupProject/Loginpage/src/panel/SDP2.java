/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package panel;

/**
 *
 * @author emiel
 */
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.jdbc.JDBCCategoryDataset;

public class SDP2 {

    /**
     * @param args the command line arguments
     */
    private static Connection con;
    public Statement st;
    private static JDBCCategoryDataset dataset;

    public void connection() {
        /*        try {
        Class.forName("org.sqlite.JDBC");
        con = DriverManager.getConnection("jdbc:sqlite:bar.db");
        st = con.createStatement();
        System.out.println("Connection is successful");
        
        Statement statement = con.createStatement();
        ResultSet resultSet = statement.executeQuery("select * from data");
        DefaultPieDataset dataset = new DefaultPieDataset();
        //  DefaultCategoryDataset bdataset = new  DefaultCategoryDataset();
        while (resultSet.next()) {
        dataset.setValue(
        resultSet.getString("Country"),
        Double.parseDouble(resultSet.getString("ecContribution")));
        }
        //   JFreeChart barChart = ChartFactory.createBarChart("EcuContribution", "EcuContribution", "Country", bdataset);
        JFreeChart chart = ChartFactory.createPieChart(
        "Ecu Contribution", // chart title
        dataset, // data
        true, // include legend
        true,
        false);
        
        int width = 560;
        
        int height = 370;
        
        
        //            ChartPanel chartpanel = new ChartPanel (barChart);
        //            chartpanel.setPreferredSize(new java.awt.Dimension(560,367));
        File pieChart = new File("Pie_Chart2.jpeg");
        ChartUtilities.saveChartAsJPEG(pieChart, chart, width, height); //chart
        
        } catch (Exception e) {
        System.out.println("Connection falied");
        System.err.println(e.getClass().getName() + ": " + e.getMessage());
        System.exit(0);
        
        }*/

        try {
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:bar.db");
            System.out.println("Connection is successful");

            dataset = new JDBCCategoryDataset(con);
            dataset.executeQuery("select * from data");

            JFreeChart barChart = ChartFactory.createBarChart(
                    "Ecu Contribution",
                    "Country",
                    "ecContribution",
                    dataset,
                    PlotOrientation.VERTICAL,
                    false, true, false);

            File pieChart = new File("Bar_Chart.jpeg");
            ChartUtilities.saveChartAsJPEG(pieChart, barChart, 560, 370);

        } catch (Exception e) {
            System.out.println("Connection falied");
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);

        }

    }

    public static void main(String[] args) {
        // TODO code application logic here
        SDP2 obj = new SDP2();
        obj.connection();

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyPanel().setVisible(true);
            }
        });

    }

}
